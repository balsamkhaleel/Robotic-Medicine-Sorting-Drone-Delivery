from controller import Supervisor
import heapq
import math

# --- 1. إعداد المشرف والأجهزة ---
robot = Supervisor()
timestep = int(robot.getBasicTimeStep())

# إحداثيات البداية والهدف الأصلية
START_X, START_Y, START_Z = -4.25, -12.58, 0.5  
GOAL_X, GOAL_Y = 39.4, -29.9 

# --- قائمة كافة العوائق التي ظهرت في الصور ---
OBSTACLES = [
    (12.4, -13.2),   # عمود إنارة 1
    (34.5, -16.0),   # عمود إنارة 2
    (18.0, -21.0),   # الشجرة (تم زيادة مسافتها لمنع الدخول فيها)
    (-1.22, -37.6)   # المنزل (BungalowStyleHouse)
]

drone_node = robot.getSelf()
drone_trans = drone_node.getField("translation")
drone_rot = drone_node.getField("rotation")

# إعادة الضبط عند التشغيل
drone_trans.setSFVec3f([START_X, START_Y, START_Z])
drone_rot.setSFRotation([0, 0, 1, 0])

package_node = robot.getFromDef("PACKAGE")
if package_node:
    package_trans = package_node.getField("translation")
    package_trans.setSFVec3f([START_X, START_Y, START_Z - 0.1])

cam = robot.getDevice("camera")
if cam: cam.enable(timestep)

# --- 2. الإعدادات وتحويل الشبكة ---
TARGET_Z = 6.0   
LANDING_Z = 0.06 
PACKAGE_OFFSET = 0.3 

def world_to_grid(x, y): return int(x + 50), int(y + 50)
def grid_to_world(gx, gy): return float(gx - 50), float(gy - 50)

OBSTACLE_GRIDS = [world_to_grid(ox, oy) for ox, oy in OBSTACLES]

# --- 3. خوارزمية A* مع تقارير الطباعة وتجنب العوائق ---
def astar(start, goal):
    print("\n" + "="*40)
    print(f"🚀 بدء التخطيط الذكي للمسار...")
    print(f"📍 البداية: {start} | 🎯 الهدف: {goal}")
    
    open_set = [(0, start)]
    came_from = {}
    g_score = {start: 0}
    nodes_explored = 0 
    
    while open_set:
        current = heapq.heappop(open_set)[1]
        nodes_explored += 1
        
        if math.dist(current, goal) < 1.2:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            
            print(f"✅ تم العثور على المسار بنجاح!")
            print(f"🔍 النقاط التي تم فحصها: {nodes_explored}")
            print(f"📏 عدد خطوات المسار: {len(path)}")
            print("="*40 + "\n")
            return path[::-1]
            
        for dx, dy in [(1,0), (-1,0), (0,1), (0,-1), (1,1), (1,-1), (-1,1), (-1,-1)]:
            neighbor = (current[0] + dx, current[1] + dy)
            
            is_obstacle = False
            for ox, oy in OBSTACLE_GRIDS:
                # تخصيص مسافات الأمان: الشجرة والمنزل يحتاجان مساحة أكبر
                if (ox, oy) == world_to_grid(18.0, -21.0) or (ox, oy) == world_to_grid(-1.22, -37.6):
                    safety_dist = 4.5 # مسافة أمان كبيرة للشجر والمنزل
                else:
                    safety_dist = 2.8 # مسافة أمان للأعمدة
                
                if math.dist(neighbor, (ox, oy)) < safety_dist:
                    is_obstacle = True
                    break
            
            if not is_obstacle and 0 <= neighbor[0] < 100 and 0 <= neighbor[1] < 100:
                step_cost = math.sqrt(dx**2 + dy**2)
                tg = g_score[current] + step_cost
                if neighbor not in g_score or tg < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tg
                    f_score = tg + math.dist(neighbor, goal)
                    heapq.heappush(open_set, (f_score, neighbor))
    
    print("❌ فشل العثور على مسار!")
    return []

path = astar(world_to_grid(START_X, START_Y), world_to_grid(GOAL_X, GOAL_Y))
target_index = 0
mode = "ASCEND"

# --- 4. حلقة التحكم الرئيسية ---
while robot.step(timestep) != -1:
    pos = drone_trans.getSFVec3f()
    curr_x, curr_y, curr_z = pos[0], pos[1], pos[2]
    new_x, new_y, new_z = curr_x, curr_y, curr_z

    if mode == "ASCEND":
        if curr_z < TARGET_Z: new_z = curr_z + 0.1
        else:
            new_z = TARGET_Z
            mode = "FLY"
            print("✈️ الإقلاع تم.. جاري اتباع المسار.")

    elif mode == "FLY":
        new_z = TARGET_Z
        if target_index < len(path):
            tx, ty = grid_to_world(path[target_index][0], path[target_index][1])
        else:
            tx, ty = GOAL_X, GOAL_Y
        
        dx, dy = tx - curr_x, ty - curr_y
        dist = math.sqrt(dx**2 + dy**2)
        
        if dist < 0.3:
            target_index += 1
            if target_index % 15 == 0: # طباعة تحديث الموقع كل 15 نقطة
                print(f"📍 تجاوز النقطة {target_index} في المسار...")
            if target_index >= len(path): mode = "LAND"
        else:
            speed = 0.15
            new_x += (dx / dist) * speed
            new_y += (dy / dist) * speed

    elif mode == "LAND":
        new_x, new_y = GOAL_X, GOAL_Y
        
        # حساب المسافة المتبقية
        dist_to_ground = curr_z - LANDING_Z
        
        # هبوط تدريجي فائق النعومة
        if dist_to_ground > 0.1:
            fall_speed = 0.02
            new_z = curr_z - fall_speed
        else:
            # قفل الإحداثيات تماماً عند الوصول للنقطة المستهدفة
            new_z = LANDING_Z
            mode = "FINISHED"
            
            # --- سطر سحري لمنع الارتداد: إيقاف أي قوة فيزيائية متبقية ---
            drone_node.resetPhysics() 
            print("🎯 تم الهبوط والاستقرار بنجاح تام.")

    if mode != "FINISHED":
        drone_trans.setSFVec3f([new_x, new_y, new_z])
        drone_rot.setSFRotation([0, 0, 1, 0])
        if package_node:
            package_trans.setSFVec3f([new_x, new_y, new_z - PACKAGE_OFFSET])